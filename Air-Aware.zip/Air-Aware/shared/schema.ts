import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { sql } from "drizzle-orm";

// === TABLE DEFINITIONS ===
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  points: integer("points").default(0),
  lungAge: integer("lung_age").default(25), // Baseline age
  badges: text("badges").array().default([]),
  createdAt: timestamp("created_at").defaultNow(),
});

export const aqiReadings = pgTable("aqi_readings", {
  id: serial("id").primaryKey(),
  location: text("location").notNull(), // e.g., "Delhi-NCR"
  aqi: integer("aqi").notNull(),
  pm25: integer("pm25").notNull(),
  pm10: integer("pm10").notNull(),
  temp: integer("temp").notNull(),
  humidity: integer("humidity").notNull(),
  status: text("status").notNull(), // Good, Moderate, Poor, Hazardous
  timestamp: timestamp("timestamp").defaultNow(),
});

export const userActions = pgTable("user_actions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  actionType: text("action_type").notNull(), // 'mask', 'clean_route', 'avoid_exposure'
  pointsEarned: integer("points_earned").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

// --- NEW TABLES FOR CHAT ---
export const conversations = pgTable("conversations", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").notNull().references(() => conversations.id, { onDelete: "cascade" }),
  role: text("role").notNull(), // 'user' | 'assistant'
  content: text("content").notNull(),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

// === SCHEMAS ===
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true, points: true, badges: true });
export const insertAqiReadingSchema = createInsertSchema(aqiReadings).omit({ id: true, timestamp: true });
export const insertUserActionSchema = createInsertSchema(userActions).omit({ id: true, timestamp: true });
export const insertConversationSchema = createInsertSchema(conversations).omit({ id: true, createdAt: true });
export const insertMessageSchema = createInsertSchema(messages).omit({ id: true, createdAt: true });

// === TYPES ===
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type AqiReading = typeof aqiReadings.$inferSelect;
export type UserAction = typeof userActions.$inferSelect;
export type Conversation = typeof conversations.$inferSelect;
export type Message = typeof messages.$inferSelect;

// Request/Response Types
export type LungAgeRequest = {
  exposureHours: number;
  sensitivity: "low" | "medium" | "high";
};

export type LungAgeResponse = {
  estimatedLungAge: number;
  message: string;
};

export type ActionResponse = {
  points: number;
  totalPoints: number;
  badges: string[];
};

export type ForecastItem = {
  date: string;
  aqi: number;
  status: string;
  recommendation: string;
};
