import { z } from 'zod';
import { insertUserSchema, users, aqiReadings } from './schema';

export const errorSchemas = {
  validation: z.object({ message: z.string(), field: z.string().optional() }),
  notFound: z.object({ message: z.string() }),
  internal: z.object({ message: z.string() }),
};

export const api = {
  aqi: {
    current: {
      method: 'GET' as const,
      path: '/api/aqi/current',
      responses: {
        200: z.custom<typeof aqiReadings.$inferSelect>(),
      },
    },
    location: {
      method: 'GET' as const,
      path: '/api/aqi/location',
      input: z.object({
        lat: z.coerce.number(),
        lon: z.coerce.number(),
      }),
      responses: {
        200: z.custom<typeof aqiReadings.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  forecast: {
    list: {
      method: 'GET' as const,
      path: '/api/forecast',
      responses: {
        200: z.array(z.object({
          date: z.string(),
          aqi: z.number(),
          status: z.string(),
          recommendation: z.string(),
        })),
      },
    },
  },
  chat: {
    send: {
      method: 'POST' as const,
      path: '/api/chat',
      input: z.object({
        messages: z.array(z.object({
          role: z.enum(['user', 'assistant']),
          content: z.string(),
        })),
      }),
      responses: {
        200: z.object({
          message: z.string(),
        }),
      },
    },
    conversations: {
      list: {
        method: 'GET' as const,
        path: '/api/conversations',
        responses: {
          200: z.array(z.any()),
        },
      },
      create: {
        method: 'POST' as const,
        path: '/api/conversations',
        input: z.object({ title: z.string() }),
        responses: {
          201: z.any(),
        },
      },
    },
  },
  users: {
    get: {
      method: 'GET' as const,
      path: '/api/users/:username',
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/users',
      input: insertUserSchema,
      responses: {
        201: z.custom<typeof users.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    action: {
      method: 'POST' as const,
      path: '/api/users/:id/action',
      input: z.object({
        actionType: z.enum(['mask', 'clean_route', 'avoid_exposure']),
      }),
      responses: {
        200: z.object({
          points: z.number(),
          totalPoints: z.number(),
          badges: z.array(z.string()),
        }),
        404: errorSchemas.notFound,
      },
    },
  },
  leaderboard: {
    list: {
      method: 'GET' as const,
      path: '/api/leaderboard',
      responses: {
        200: z.array(z.custom<typeof users.$inferSelect>()),
      },
    },
  },
  health: {
    calculateLungAge: {
      method: 'POST' as const,
      path: '/api/health/lung-age',
      input: z.object({
        exposureHours: z.number(),
        sensitivity: z.enum(["low", "medium", "high"]),
      }),
      responses: {
        200: z.object({
          estimatedLungAge: z.number(),
          message: z.string(),
        }),
      },
    },
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
