import { PieChart, Pie, Cell, ResponsiveContainer } from "recharts";
import { motion } from "framer-motion";

interface AqiGaugeProps {
  aqi: number;
  status: string;
}

export function AqiGauge({ aqi, status }: AqiGaugeProps) {
  // Determine color based on AQI
  const getColor = (value: number) => {
    if (value <= 50) return "#22c55e"; // Green
    if (value <= 100) return "#eab308"; // Yellow
    if (value <= 150) return "#f97316"; // Orange
    if (value <= 200) return "#ef4444"; // Red
    if (value <= 300) return "#a855f7"; // Purple
    return "#7f1d1d"; // Maroon
  };

  const color = getColor(aqi);

  // Data for the gauge
  const data = [
    { name: "AQI", value: Math.min(aqi, 500) },
    { name: "Remaining", value: 500 - Math.min(aqi, 500) },
  ];

  return (
    <div className="relative h-64 w-full flex items-center justify-center">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            startAngle={180}
            endAngle={0}
            innerRadius={80}
            outerRadius={100}
            paddingAngle={0}
            dataKey="value"
            stroke="none"
          >
            <Cell fill={color} className="drop-shadow-[0_0_10px_rgba(0,0,0,0.5)]" />
            <Cell fill="rgba(255,255,255,0.05)" />
          </Pie>
        </PieChart>
      </ResponsiveContainer>
      
      <div className="absolute inset-0 flex flex-col items-center justify-center pt-10 pointer-events-none">
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="text-center"
        >
          <div className="text-6xl font-bold font-display tracking-tighter" style={{ color }}>
            {aqi}
          </div>
          <div className="text-xs uppercase tracking-widest text-muted-foreground mt-2 font-mono">
            US AQI
          </div>
          <div 
            className="mt-4 px-3 py-1 rounded-full text-sm font-semibold border bg-background/50 backdrop-blur-sm"
            style={{ borderColor: color, color: color }}
          >
            {status}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
