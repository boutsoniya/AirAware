import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Calculator, Wallet, HeartPulse, Pill, TrendingDown } from "lucide-react";
import { GlassCard } from "./GlassCard";

export function HealthCostCalculator({ currentAqi }: { currentAqi: number }) {
  const [age, setAge] = useState(25);
  const [hours, setHours] = useState(2);

  const ageMultiplier = age < 12 || age > 60 ? 1.5 : 1.0;
  const monthlyCost = Math.round((currentAqi / 10) * hours * ageMultiplier * 15);
  const yearlySavings = monthlyCost * 12;

  const breakdown = {
    doctor: Math.round(monthlyCost * 0.4),
    medication: Math.round(monthlyCost * 0.35),
    productivity: Math.round(monthlyCost * 0.25),
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2 bg-white/5 border-white/10 hover:bg-white/10">
          <Calculator className="w-4 h-4" />
          Health Cost Calculator
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px] bg-[#121212]/95 backdrop-blur-xl border-white/10 text-white">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-2xl font-bold">
            <Calculator className="w-6 h-6 text-primary" />
            Health Cost Estimator
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-8 py-6">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-white/60">Your Age: {age}</label>
            </div>
            <Slider
              value={[age]}
              onValueChange={([v]) => setAge(v)}
              max={100}
              step={1}
              className="py-4"
            />
          </div>

          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-white/60">Hours outdoors/day: {hours}</label>
            </div>
            <Slider
              value={[hours]}
              onValueChange={([v]) => setHours(v)}
              max={24}
              step={1}
              className="py-4"
            />
          </div>

          <div className="grid grid-cols-1 gap-4 pt-4">
            <div className="p-6 rounded-2xl bg-primary/10 border border-primary/20 flex flex-col items-center">
              <Wallet className="w-8 h-8 text-primary mb-2" />
              <div className="text-sm text-white/60">Monthly health impact</div>
              <div className="text-4xl font-bold text-primary">₹{monthlyCost}</div>
            </div>

            <div className="p-4 rounded-xl bg-green-500/10 border border-green-500/20 flex items-center gap-4">
              <TrendingDown className="w-6 h-6 text-green-400" />
              <div>
                <div className="text-xs text-white/60">Clean air city saves you</div>
                <div className="text-lg font-bold text-green-400">₹{yearlySavings}/year</div>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="text-sm font-semibold text-white/80">Monthly Breakdown</h4>
            <div className="grid grid-cols-3 gap-3">
              <div className="p-3 rounded-lg bg-white/5 border border-white/10 text-center">
                <HeartPulse className="w-4 h-4 text-rose-400 mx-auto mb-1" />
                <div className="text-[10px] text-white/40 mb-1">Doctor</div>
                <div className="text-sm font-bold">₹{breakdown.doctor}</div>
              </div>
              <div className="p-3 rounded-lg bg-white/5 border border-white/10 text-center">
                <Pill className="w-4 h-4 text-cyan-400 mx-auto mb-1" />
                <div className="text-[10px] text-white/40 mb-1">Medicine</div>
                <div className="text-sm font-bold">₹{breakdown.medication}</div>
              </div>
              <div className="p-3 rounded-lg bg-white/5 border border-white/10 text-center">
                <TrendingDown className="w-4 h-4 text-amber-400 mx-auto mb-1" />
                <div className="text-[10px] text-white/40 mb-1">Productivity</div>
                <div className="text-sm font-bold">₹{breakdown.productivity}</div>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
