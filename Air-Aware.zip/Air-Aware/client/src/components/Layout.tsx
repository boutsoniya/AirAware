import { ReactNode, useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Wind, Activity, Trophy, User, Menu, X, LogIn } from "lucide-react";
import { cn } from "@/lib/utils";
import { useUser } from "@/hooks/use-users";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useCreateUser } from "@/hooks/use-users";

import { motion } from "framer-motion";

export function Layout({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [username, setUsername] = useState<string | null>(localStorage.getItem("airaware_user"));
  const { data: user } = useUser(username || "");
  const createUser = useCreateUser();
  const [newUsername, setNewUsername] = useState("");
  const [isLoginOpen, setIsLoginOpen] = useState(false);

  const handleRefresh = () => {
    window.location.href = "/";
  };

  const handleLogin = async () => {
    if (!newUsername.trim()) return;
    
    try {
      // Try to create user (backend handles duplicate error gracefully or we just fetch)
      // For this MVP, we assume create is "login/register" combined essentially
      // Or we try to fetch first.
      // Let's just create. If it fails with "already exists", we just set the local storage.
      // Ideally, the API would have a distinct login, but we'll use create for simplicity 
      // or catch the error and proceed.
      
      try {
        await createUser.mutateAsync({ username: newUsername, password: "password" }); // Dummy password for MVP
      } catch (e) {
        // If it fails, assume user exists and proceed (in a real app, handle auth properly)
        console.log("User might already exist, logging in...");
      }
      
      localStorage.setItem("airaware_user", newUsername);
      setUsername(newUsername);
      setIsLoginOpen(false);
    } catch (error) {
      console.error(error);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("airaware_user");
    setUsername(null);
  };

  const navItems = [
    { href: "/", label: "Dashboard", icon: Wind },
    { href: "/health", label: "Lung Health", icon: Activity },
    { href: "/leaderboard", label: "Leaderboard", icon: Trophy },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col md:flex-row font-sans selection:bg-primary selection:text-white">
      {/* Mobile Header */}
      <div className="md:hidden flex items-center justify-between p-4 border-b border-white/10 bg-background/50 backdrop-blur-lg sticky top-0 z-50">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-blue-500 flex items-center justify-center shadow-[0_0_15px_rgba(34,197,94,0.4)]">
            <Wind className="w-5 h-5 text-white" />
          </div>
          <span className="font-display font-bold text-lg tracking-wide">AirAware</span>
        </div>
        <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
          {isMobileMenuOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Sidebar Navigation */}
      <aside 
        className={cn(
          "fixed md:sticky top-0 left-0 z-40 h-screen w-64 bg-card border-r border-white/5 flex flex-col transition-transform duration-300 ease-in-out md:translate-x-0",
          isMobileMenuOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="p-6 flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-emerald-600 flex items-center justify-center shadow-lg shadow-primary/20">
            <Wind className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="font-display font-bold text-xl tracking-wider">AirAware</h1>
            <p className="text-xs text-muted-foreground font-mono">v1.0.0-beta</p>
          </div>
        </div>

        <nav className="flex-1 px-4 space-y-2">
          {navItems.map((item) => {
            const isActive = location === item.href;
            return (
              <Link key={item.href} href={item.href} className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group relative overflow-hidden",
                isActive 
                  ? "bg-primary/10 text-primary font-medium shadow-[0_0_20px_rgba(34,197,94,0.1)]" 
                  : "text-muted-foreground hover:text-foreground hover:bg-white/5"
              )}>
                {isActive && (
                  <div className="absolute left-0 top-0 bottom-0 w-1 bg-primary shadow-[0_0_10px_var(--primary)]" />
                )}
                <item.icon className={cn("w-5 h-5", isActive && "animate-pulse")} />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-white/5">
          {user ? (
            <div className="bg-white/5 rounded-2xl p-4 border border-white/5">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold font-display">
                  {user.username.substring(0, 2).toUpperCase()}
                </div>
                <div className="overflow-hidden">
                  <p className="font-medium truncate">{user.username}</p>
                  <p className="text-xs text-primary font-mono">{user.points} XP</p>
                </div>
              </div>
              <Button variant="ghost" size="sm" onClick={handleLogout} className="w-full text-xs h-8 text-muted-foreground hover:text-destructive">
                Log Out
              </Button>
            </div>
          ) : (
            <Dialog open={isLoginOpen} onOpenChange={setIsLoginOpen}>
              <DialogTrigger asChild>
                <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg shadow-primary/20">
                  <LogIn className="w-4 h-4 mr-2" /> Login
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md bg-card border-white/10 text-foreground">
                <DialogHeader>
                  <DialogTitle className="font-display text-2xl">Welcome Back</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-muted-foreground">Username</label>
                    <Input 
                      placeholder="Enter username" 
                      value={newUsername}
                      onChange={(e) => setNewUsername(e.target.value)}
                      className="bg-white/5 border-white/10 focus:border-primary/50"
                    />
                  </div>
                  <Button 
                    onClick={handleLogin} 
                    disabled={createUser.isPending}
                    className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                  >
                    {createUser.isPending ? "Connecting..." : "Continue"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-x-hidden">
        <div className="max-w-7xl mx-auto p-4 md:p-8 lg:p-12 pb-24">
          {children}
        </div>
      </main>
    </div>
  );
}
