import { useState, useMemo } from "react";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from "chart.js";
import { Line } from "react-chartjs-2";
import { GlassCard } from "./GlassCard";
import { Clock, TrendingDown, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

export function CommutePlanner() {
  const [startTime, setStartTime] = useState("08:00");

  const mockData = useMemo(() => {
    const labels = Array.from({ length: 24 }, (_, i) => `${i}:00`);
    const data = Array.from({ length: 24 }, (_, i) => {
      // Peaks at 8-9 AM (350), lowest at 11 AM-2 PM (180)
      if (i >= 8 && i <= 9) return 350 - (Math.random() * 20);
      if (i >= 11 && i <= 14) return 180 + (Math.random() * 20);
      if (i >= 18 && i <= 20) return 300 - (Math.random() * 20);
      return 220 + (Math.random() * 40);
    });
    return { labels, data };
  }, []);

  const safestWindow = useMemo(() => {
    const minAqi = Math.min(...mockData.data);
    const minIndex = mockData.data.indexOf(minAqi);
    return {
      time: mockData.labels[minIndex],
      index: minIndex,
      aqi: Math.round(minAqi),
    };
  }, [mockData]);

  const currentSelectionAqi = useMemo(() => {
    const hour = parseInt(startTime.split(":")[0]);
    return Math.round(mockData.data[hour]);
  }, [startTime, mockData]);

  const savings = Math.round(((currentSelectionAqi - safestWindow.aqi) / currentSelectionAqi) * 100);

  const chartData = {
    labels: mockData.labels,
    datasets: [
      {
        label: "Predicted AQI",
        data: mockData.data,
        fill: true,
        borderColor: "rgb(34, 197, 94)",
        backgroundColor: "rgba(34, 197, 94, 0.1)",
        tension: 0.4,
        pointRadius: 0,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: {
        mode: "index" as const,
        intersect: false,
      },
    },
    scales: {
      y: {
        grid: { color: "rgba(255, 255, 255, 0.05)" },
        ticks: { color: "rgba(255, 255, 255, 0.5)" },
      },
      x: {
        grid: { display: false },
        ticks: { color: "rgba(255, 255, 255, 0.5)" },
      },
    },
  };

  return (
    <GlassCard className="p-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <div>
          <h3 className="text-xl font-bold text-white flex items-center gap-2">
            <Clock className="w-6 h-6 text-primary" />
            Commute Planner
          </h3>
          <p className="text-sm text-white/60">Find the safest window for your travel</p>
        </div>
        <div className="flex items-center gap-3">
          <label className="text-sm text-white/60">Start Time:</label>
          <input
            type="time"
            value={startTime}
            onChange={(e) => setStartTime(e.target.value)}
            className="bg-white/5 border border-white/10 rounded-md px-3 py-1 text-white focus:outline-none focus:ring-1 focus:ring-primary"
          />
        </div>
      </div>

      <div className="h-[200px] mb-6">
        <Line data={chartData} options={chartOptions} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-4 rounded-xl bg-white/5 border border-white/10 flex items-start gap-3">
          <TrendingDown className="w-5 h-5 text-primary mt-1" />
          <div>
            <div className="text-sm font-medium text-white">Recommendation</div>
            <div className="text-lg font-bold text-primary">
              Leave at {safestWindow.time}
            </div>
            <div className="text-xs text-white/60">
              {savings}% less pollution than your {startTime} slot
            </div>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-primary/10 border border-primary/20 flex items-start gap-3">
          <CheckCircle2 className="w-5 h-5 text-primary mt-1" />
          <div>
            <div className="text-sm font-medium text-white">Status</div>
            <div className="text-lg font-bold text-white">
              AQI {currentSelectionAqi} at {startTime}
            </div>
            <div className="text-xs text-white/60">
              Safest AQI today: {safestWindow.aqi}
            </div>
          </div>
        </div>
      </div>
    </GlassCard>
  );
}
