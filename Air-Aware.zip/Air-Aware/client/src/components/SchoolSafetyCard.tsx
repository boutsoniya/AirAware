import { GlassCard } from "./GlassCard";
import { Shield, Users, AlertCircle, CheckCircle, XCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export function SchoolSafetyCard({ currentAqi }: { currentAqi: number }) {
  const { toast } = useToast();

  const getGrapStage = (aqi: number) => {
    if (aqi <= 200) return { stage: "Stage I", color: "bg-green-500/20 text-green-400 border-green-500/50", label: "Moderate" };
    if (aqi <= 300) return { stage: "Stage II", color: "bg-yellow-500/20 text-yellow-400 border-yellow-500/50", label: "Very Poor" };
    if (aqi <= 400) return { stage: "Stage III", color: "bg-orange-500/20 text-orange-400 border-orange-500/50", label: "Severe" };
    return { stage: "Stage IV", color: "bg-red-500/20 text-red-400 border-red-500/50", label: "Severe Plus" };
  };

  const getSafetyStatus = (aqi: number) => {
    if (aqi < 200) return { status: "Outdoor activities safe ✓", icon: CheckCircle, color: "text-green-400" };
    if (aqi <= 300) return { status: "Limit outdoor time to 30 min", icon: AlertCircle, color: "text-yellow-400" };
    return { status: "Cancel all outdoor activities ✗", icon: XCircle, color: "text-red-400" };
  };

  const grap = getGrapStage(currentAqi);
  const safety = getSafetyStatus(currentAqi);

  const handleNotify = () => {
    toast({
      title: "Notification Sent",
      description: "Parents have been notified about the school safety status.",
    });
  };

  return (
    <GlassCard className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-primary/10 text-primary">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white">School Safety Status</h3>
            <p className="text-sm text-white/60">Delhi GRAP Compliance</p>
          </div>
        </div>
        <Badge className={`border py-1 px-3 ${grap.color}`}>
          {grap.stage}: {grap.label}
        </Badge>
      </div>

      <div className="flex items-center gap-4 p-4 rounded-xl bg-white/5 border border-white/10 mb-6">
        <safety.icon className={`w-8 h-8 ${safety.color}`} />
        <div>
          <div className="text-sm text-white/60">Action Logic</div>
          <div className={`text-lg font-bold ${safety.color}`}>{safety.status}</div>
        </div>
      </div>

      <Button 
        onClick={handleNotify}
        className="w-full gap-2 bg-primary/20 hover:bg-primary/30 text-primary border border-primary/50"
      >
        <Shield className="w-4 h-4" />
        Notify Parents
      </Button>
    </GlassCard>
  );
}
