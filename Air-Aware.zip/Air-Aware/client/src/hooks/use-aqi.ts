import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";

export function useCurrentAqi() {
  return useQuery({
    queryKey: [api.aqi.current.path],
    queryFn: async () => {
      const res = await fetch(api.aqi.current.path);
      if (!res.ok) throw new Error("Failed to fetch AQI data");
      return api.aqi.current.responses[200].parse(await res.json());
    },
    refetchInterval: 60000, // Poll every minute
  });
}
