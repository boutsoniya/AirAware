import { useMutation } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useLungAge() {
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: { exposureHours: number; sensitivity: "low" | "medium" | "high" }) => {
      const res = await fetch(api.health.calculateLungAge.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to calculate");
      return api.health.calculateLungAge.responses[200].parse(await res.json());
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Could not calculate lung age.",
        variant: "destructive",
      });
    },
  });
}
