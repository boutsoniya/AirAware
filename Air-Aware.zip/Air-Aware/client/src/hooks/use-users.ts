import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type InsertUser } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useUser(username: string) {
  return useQuery({
    queryKey: [api.users.get.path, username],
    queryFn: async () => {
      const url = buildUrl(api.users.get.path, { username });
      const res = await fetch(url);
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch user");
      return api.users.get.responses[200].parse(await res.json());
    },
    enabled: !!username,
  });
}

export function useCreateUser() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: InsertUser) => {
      const res = await fetch(api.users.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to create user");
      }
      return api.users.create.responses[201].parse(await res.json());
    },
    onSuccess: (data) => {
      queryClient.setQueryData([api.users.get.path, data.username], data);
      // Invalidate leaderboard too since a new user exists
      queryClient.invalidateQueries({ queryKey: [api.leaderboard.list.path] });
    },
    onError: (error) => {
      toast({
        title: "Registration Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

export function useUserAction() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, actionType }: { id: number; actionType: 'mask' | 'clean_route' | 'avoid_exposure' }) => {
      const url = buildUrl(api.users.action.path, { id });
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ actionType }),
      });
      if (!res.ok) throw new Error("Failed to log action");
      return api.users.action.responses[200].parse(await res.json());
    },
    onSuccess: (data, variables) => {
      // We don't have the username in variables, so we might need to invalidate all users or manage state carefully
      // For simplicity, we invalidate the specific user queries if we had the username, but here we'll invalidate leaderboard
      queryClient.invalidateQueries({ queryKey: [api.leaderboard.list.path] });
      // And maybe generic user queries
      queryClient.invalidateQueries({ queryKey: [api.users.get.path] });

      toast({
        title: "Action Logged!",
        description: `You earned ${data.points} points. Total: ${data.totalPoints}`,
        className: "border-primary text-primary-foreground bg-primary",
      });
      
      if (data.badges.length > 0) {
        toast({
          title: "New Badge Unlocked!",
          description: data.badges[data.badges.length - 1],
          className: "border-accent text-accent-foreground bg-accent neon-border",
        });
      }
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to log action. Please try again.",
        variant: "destructive",
      });
    }
  });
}

export function useLeaderboard() {
  return useQuery({
    queryKey: [api.leaderboard.list.path],
    queryFn: async () => {
      const res = await fetch(api.leaderboard.list.path);
      if (!res.ok) throw new Error("Failed to fetch leaderboard");
      return api.leaderboard.list.responses[200].parse(await res.json());
    },
  });
}
