import { useState } from "react";
import { useLungAge } from "@/hooks/use-health";
import { GlassCard } from "@/components/GlassCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Activity, Clock, HeartPulse } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function Health() {
  const [exposureHours, setExposureHours] = useState<string>("2");
  const [sensitivity, setSensitivity] = useState<"low" | "medium" | "high">("medium");
  const lungAgeMutation = useLungAge();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    lungAgeMutation.mutate({
      exposureHours: parseFloat(exposureHours),
      sensitivity,
    });
  };

  return (
    <div className="max-w-4xl mx-auto">
      <header className="mb-12 text-center">
        <h1 className="text-4xl md:text-5xl font-bold font-display mb-4 bg-gradient-to-r from-pink-500 to-rose-500 bg-clip-text text-transparent">
          Lung Health Estimator
        </h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Calculate the effective age of your lungs based on current pollution exposure levels and your personal sensitivity.
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
        <GlassCard className="p-8">
          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="space-y-4">
              <Label className="text-base font-medium flex items-center gap-2">
                <Clock className="w-4 h-4 text-primary" />
                Hours spent outdoors today
              </Label>
              <div className="relative">
                <Input
                  type="number"
                  min="0"
                  max="24"
                  step="0.5"
                  value={exposureHours}
                  onChange={(e) => setExposureHours(e.target.value)}
                  className="bg-white/5 border-white/10 text-lg py-6 focus:border-primary/50"
                />
                <span className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">hours</span>
              </div>
            </div>

            <div className="space-y-4">
              <Label className="text-base font-medium flex items-center gap-2">
                <HeartPulse className="w-4 h-4 text-rose-500" />
                Respiratory Sensitivity
              </Label>
              <RadioGroup 
                value={sensitivity} 
                onValueChange={(val) => setSensitivity(val as any)}
                className="grid grid-cols-3 gap-4"
              >
                <div>
                  <RadioGroupItem value="low" id="low" className="peer sr-only" />
                  <Label
                    htmlFor="low"
                    className="flex flex-col items-center justify-between rounded-xl border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary peer-data-[state=checked]:text-primary cursor-pointer transition-all"
                  >
                    <span className="mb-2 text-xl">💪</span>
                    Low
                  </Label>
                </div>
                <div>
                  <RadioGroupItem value="medium" id="medium" className="peer sr-only" />
                  <Label
                    htmlFor="medium"
                    className="flex flex-col items-center justify-between rounded-xl border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary peer-data-[state=checked]:text-primary cursor-pointer transition-all"
                  >
                    <span className="mb-2 text-xl">😐</span>
                    Medium
                  </Label>
                </div>
                <div>
                  <RadioGroupItem value="high" id="high" className="peer sr-only" />
                  <Label
                    htmlFor="high"
                    className="flex flex-col items-center justify-between rounded-xl border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary peer-data-[state=checked]:text-primary cursor-pointer transition-all"
                  >
                    <span className="mb-2 text-xl">😮‍💨</span>
                    High
                  </Label>
                </div>
              </RadioGroup>
            </div>

            <Button 
              type="submit" 
              size="lg"
              disabled={lungAgeMutation.isPending}
              className="w-full bg-gradient-to-r from-primary to-emerald-600 hover:from-primary/90 hover:to-emerald-600/90 text-white font-bold h-12 rounded-xl shadow-lg shadow-primary/20"
            >
              {lungAgeMutation.isPending ? "Calculating..." : "Calculate Impact"}
            </Button>
          </form>
        </GlassCard>

        <div className="space-y-6">
          <AnimatePresence mode="wait">
            {lungAgeMutation.data ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.4 }}
              >
                <GlassCard className="bg-gradient-to-br from-rose-500/10 to-transparent border-rose-500/20">
                  <div className="text-center p-6 space-y-6">
                    <Activity className="w-16 h-16 text-rose-500 mx-auto animate-pulse" />
                    
                    <div>
                      <div className="text-sm text-muted-foreground uppercase tracking-widest mb-2">Estimated Lung Age</div>
                      <div className="text-7xl font-bold font-display text-rose-500 neon-text">
                        {lungAgeMutation.data.estimatedLungAge}
                      </div>
                      <div className="text-xl text-muted-foreground mt-2">years old</div>
                    </div>

                    <div className="bg-white/5 p-6 rounded-2xl border border-white/5">
                      <p className="text-lg leading-relaxed font-light">
                        "{lungAgeMutation.data.message}"
                      </p>
                    </div>

                    <div className="flex gap-2 justify-center">
                      <div className="w-2 h-2 rounded-full bg-rose-500 animate-bounce" style={{ animationDelay: '0s' }} />
                      <div className="w-2 h-2 rounded-full bg-rose-500 animate-bounce" style={{ animationDelay: '0.1s' }} />
                      <div className="w-2 h-2 rounded-full bg-rose-500 animate-bounce" style={{ animationDelay: '0.2s' }} />
                    </div>
                  </div>
                </GlassCard>
              </motion.div>
            ) : (
              <GlassCard className="flex flex-col items-center justify-center min-h-[400px] text-center p-8 opacity-60">
                <div className="w-20 h-20 rounded-full bg-white/5 flex items-center justify-center mb-6">
                  <Activity className="w-10 h-10 text-muted-foreground" />
                </div>
                <h3 className="text-xl font-bold mb-2">Ready to Calculate</h3>
                <p className="text-muted-foreground">
                  Enter your outdoor exposure details to see how the current air quality is impacting your respiratory health.
                </p>
              </GlassCard>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
