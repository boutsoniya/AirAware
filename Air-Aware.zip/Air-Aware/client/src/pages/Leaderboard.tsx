import { useLeaderboard } from "@/hooks/use-users";
import { GlassCard } from "@/components/GlassCard";
import { Trophy, Medal, Crown } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

export default function Leaderboard() {
  const { data: users, isLoading } = useLeaderboard();

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3, 4, 5].map((i) => (
          <Skeleton key={i} className="h-20 w-full rounded-2xl bg-white/5" />
        ))}
      </div>
    );
  }

  // Sort users by points desc
  const sortedUsers = [...(users || [])].sort((a, b) => (b.points || 0) - (a.points || 0));

  return (
    <div className="max-w-4xl mx-auto">
      <header className="mb-10 flex items-center gap-4">
        <div className="p-4 bg-yellow-500/20 rounded-2xl border border-yellow-500/20 text-yellow-500">
          <Trophy className="w-8 h-8" />
        </div>
        <div>
          <h1 className="text-4xl font-bold font-display">Eco Champions</h1>
          <p className="text-muted-foreground">Top contributors to cleaner air habits</p>
        </div>
      </header>

      <div className="space-y-4">
        {sortedUsers.map((user, index) => {
          const isTop3 = index < 3;
          return (
            <GlassCard 
              key={user.id} 
              delay={index * 0.1}
              className={cn(
                "flex items-center gap-6 p-4 transition-all duration-300 hover:bg-white/10",
                index === 0 ? "border-yellow-500/30 bg-yellow-500/5" :
                index === 1 ? "border-gray-400/30 bg-gray-400/5" :
                index === 2 ? "border-amber-700/30 bg-amber-700/5" : ""
              )}
            >
              <div className="font-display font-bold text-2xl w-12 text-center text-muted-foreground">
                {index === 0 ? <Crown className="w-8 h-8 text-yellow-500 mx-auto" /> : `#${index + 1}`}
              </div>

              <div className="relative">
                <div className={cn(
                  "w-12 h-12 rounded-full flex items-center justify-center text-white font-bold font-display text-lg",
                  index === 0 ? "bg-yellow-500 shadow-[0_0_15px_rgba(234,179,8,0.5)]" :
                  index === 1 ? "bg-gray-400" :
                  index === 2 ? "bg-amber-700" : "bg-white/10"
                )}>
                  {user.username.substring(0, 2).toUpperCase()}
                </div>
              </div>

              <div className="flex-1">
                <h3 className="font-bold text-lg flex items-center gap-2">
                  {user.username}
                  {isTop3 && <Medal className="w-4 h-4 text-yellow-500" />}
                </h3>
                <div className="flex gap-2 mt-1 flex-wrap">
                  {user.badges?.map((badge, i) => (
                    <span key={i} className="text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full bg-white/5 border border-white/10 text-muted-foreground">
                      {badge}
                    </span>
                  ))}
                </div>
              </div>

              <div className="text-right">
                <div className="font-mono font-bold text-2xl text-primary neon-text">
                  {user.points}
                </div>
                <div className="text-xs text-muted-foreground uppercase tracking-wider">XP Earned</div>
              </div>
            </GlassCard>
          );
        })}

        {sortedUsers.length === 0 && (
          <div className="text-center py-20 text-muted-foreground">
            No champions yet. Be the first to log an action!
          </div>
        )}
      </div>
    </div>
  );
}
