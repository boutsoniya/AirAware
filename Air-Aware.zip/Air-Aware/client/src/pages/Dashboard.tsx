import { useCurrentAqi } from "@/hooks/use-aqi";
import { useUser, useUserAction } from "@/hooks/use-users";
import { AqiGauge } from "@/components/AqiGauge";
import { GlassCard } from "@/components/GlassCard";
import { Wind, Thermometer, Droplets, Shield, MapPin, Footprints, Info } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { HealthCostCalculator } from "@/components/HealthCostCalculator";
import { CommutePlanner } from "@/components/CommutePlanner";
import { SchoolSafetyCard } from "@/components/SchoolSafetyCard";

export default function Dashboard() {
  const { data: aqiData, isLoading } = useCurrentAqi();
  const username = localStorage.getItem("airaware_user");
  const { data: user } = useUser(username || "");
  const actionMutation = useUserAction();

  const { data: forecast, isLoading: forecastLoading } = useQuery<any[]>({
    queryKey: ["/api/forecast"],
  });

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "good": return "bg-green-500/20 text-green-400 border-green-500/50";
      case "moderate": return "bg-yellow-500/20 text-yellow-400 border-yellow-500/50";
      case "poor": return "bg-orange-500/20 text-orange-400 border-orange-500/50";
      case "hazardous": return "bg-red-500/20 text-red-400 border-red-500/50";
      default: return "bg-gray-500/20 text-gray-400 border-gray-500/50";
    }
  };

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Skeleton className="h-64 w-full rounded-3xl bg-white/5" />
        <Skeleton className="h-64 w-full rounded-3xl bg-white/5" />
        <Skeleton className="h-64 w-full rounded-3xl bg-white/5" />
      </div>
    );
  }

  if (!aqiData) return <div>Failed to load data</div>;

  const handleAction = (type: 'mask' | 'clean_route' | 'avoid_exposure') => {
    if (!user) return; // Should prompt login
    actionMutation.mutate({ id: user.id, actionType: type });
  };

  return (
    <div className="space-y-8">
      <header className="mb-10">
        <motion.h1 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl md:text-5xl font-bold font-display mb-2 bg-gradient-to-r from-white to-white/60 bg-clip-text text-transparent"
        >
          Air Quality Monitor
        </motion.h1>
        <div className="flex items-center gap-2 text-muted-foreground">
          <MapPin className="w-4 h-4" />
          <span>{aqiData.location}</span>
          <span className="mx-2">•</span>
          <span>Last updated: {new Date().toLocaleTimeString()}</span>
          <span className="mx-2">•</span>
          <HealthCostCalculator currentAqi={aqiData.aqi} />
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main AQI Gauge */}
        <GlassCard className="col-span-1 lg:col-span-2 flex flex-col md:flex-row items-center justify-between min-h-[300px]">
          <div className="w-full md:w-1/2 flex flex-col items-center justify-center p-4">
            <AqiGauge aqi={aqiData.aqi} status={aqiData.status} />
          </div>
          <div className="w-full md:w-1/2 p-6 border-t md:border-t-0 md:border-l border-white/5 space-y-6">
            <h3 className="text-lg font-medium text-white/80 flex items-center gap-2">
              <Info className="w-4 h-4" /> Health Advice
            </h3>
            <p className="text-2xl font-light leading-relaxed">
              {aqiData.aqi <= 50 ? "Air quality is excellent. Enjoy outdoor activities!" :
               aqiData.aqi <= 100 ? "Air quality is acceptable. Sensitive individuals should consider limiting prolonged outdoor exertion." :
               aqiData.aqi <= 150 ? "Members of sensitive groups may experience health effects. The general public is less likely to be affected." :
               "Health alert: everyone may experience more serious health effects."}
            </p>
            
            <div className="flex gap-2">
               {aqiData.aqi > 100 && (
                 <div className="px-3 py-1 rounded-md bg-red-500/10 border border-red-500/20 text-red-500 text-sm flex items-center gap-2">
                   <Shield className="w-3 h-3" /> Mask Recommended
                 </div>
               )}
            </div>
          </div>
        </GlassCard>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 gap-6">
          <GlassCard delay={0.1} className="flex flex-col justify-center">
            <div className="flex items-center gap-4 mb-4">
              <div className="p-3 rounded-2xl bg-blue-500/10 text-blue-400">
                <Wind className="w-6 h-6" />
              </div>
              <div>
                <div className="text-sm text-muted-foreground">Particulate Matter</div>
                <div className="font-display text-xl font-bold">PM2.5</div>
              </div>
              <div className="ml-auto text-3xl font-mono font-bold">{aqiData.pm25}</div>
            </div>
            <div className="w-full bg-white/5 rounded-full h-1.5 mt-2">
              <div 
                className="h-full rounded-full bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.5)]" 
                style={{ width: `${Math.min((aqiData.pm25 / 100) * 100, 100)}%` }}
              />
            </div>
          </GlassCard>

          <GlassCard delay={0.2} className="flex flex-col justify-center">
            <div className="flex items-center gap-4 mb-4">
              <div className="p-3 rounded-2xl bg-orange-500/10 text-orange-400">
                <Wind className="w-6 h-6" />
              </div>
              <div>
                <div className="text-sm text-muted-foreground">Particulate Matter</div>
                <div className="font-display text-xl font-bold">PM10</div>
              </div>
              <div className="ml-auto text-3xl font-mono font-bold">{aqiData.pm10}</div>
            </div>
            <div className="w-full bg-white/5 rounded-full h-1.5 mt-2">
              <div 
                className="h-full rounded-full bg-orange-500 shadow-[0_0_10px_rgba(249,115,22,0.5)]" 
                style={{ width: `${Math.min((aqiData.pm10 / 200) * 100, 100)}%` }}
              />
            </div>
          </GlassCard>

          <div className="grid grid-cols-2 gap-4">
            <GlassCard delay={0.3} className="flex flex-col items-center justify-center p-4">
              <Thermometer className="w-6 h-6 text-rose-400 mb-2" />
              <div className="text-2xl font-bold font-mono">{aqiData.temp}°C</div>
              <div className="text-xs text-muted-foreground">Temperature</div>
            </GlassCard>
            <GlassCard delay={0.4} className="flex flex-col items-center justify-center p-4">
              <Droplets className="w-6 h-6 text-cyan-400 mb-2" />
              <div className="text-2xl font-bold font-mono">{aqiData.humidity}%</div>
              <div className="text-xs text-muted-foreground">Humidity</div>
            </GlassCard>
          </div>
        </div>
      </div>

      {/* 7-Day Predictor Table */}
      <GlassCard className="p-6">
        <h3 className="text-xl font-display font-bold text-white mb-6">7-Day AQI Predictor</h3>
        <div className="overflow-x-auto">
          <Table data-testid="table-forecast">
            <TableHeader>
              <TableRow className="border-white/10 hover:bg-transparent">
                <TableHead className="text-white/60">Date</TableHead>
                <TableHead className="text-white/60">Predicted AQI</TableHead>
                <TableHead className="text-white/60">Category</TableHead>
                <TableHead className="text-white/60">Recommended Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {forecastLoading ? (
                Array.from({ length: 7 }).map((_, i) => (
                  <TableRow key={i} className="border-white/10">
                    <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-12" /></TableCell>
                    <TableCell><Skeleton className="h-6 w-20" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-48" /></TableCell>
                  </TableRow>
                ))
              ) : (
                forecast?.map((day) => (
                  <TableRow key={day.date} className="border-white/10 hover:bg-white/5 transition-colors" data-testid={`card-forecast-day-${day.date}`}>
                    <TableCell className="text-white font-medium">
                      {new Date(day.date).toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' })}
                    </TableCell>
                    <TableCell className="text-white font-mono">{day.aqi}</TableCell>
                    <TableCell>
                      <Badge className={`border ${getStatusColor(day.status)}`}>
                        {day.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-white/80">{day.recommendation}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </GlassCard>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <CommutePlanner />
        <SchoolSafetyCard currentAqi={aqiData.aqi} />
      </div>

      {/* Action Section */}
      <section className="mt-12">
        <h2 className="text-2xl font-display font-bold mb-6 flex items-center gap-2">
          <Shield className="w-6 h-6 text-primary" /> 
          Take Action
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <GlassCard className="border-primary/20 hover:border-primary/50 transition-colors" delay={0.5}>
            <div className="p-3 rounded-full bg-primary/10 w-fit mb-4 text-primary">
              <Shield className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold mb-2">Wore a Mask</h3>
            <p className="text-sm text-muted-foreground mb-6">
              Logged when you wear an N95/KN95 mask outdoors.
            </p>
            <Button 
              onClick={() => handleAction('mask')} 
              disabled={!user || actionMutation.isPending}
              className="w-full bg-primary/20 hover:bg-primary/30 text-primary border border-primary/50"
            >
              Log (+50 XP)
            </Button>
          </GlassCard>

          <GlassCard className="border-blue-500/20 hover:border-blue-500/50 transition-colors" delay={0.6}>
            <div className="p-3 rounded-full bg-blue-500/10 w-fit mb-4 text-blue-400">
              <MapPin className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold mb-2">Clean Route</h3>
            <p className="text-sm text-muted-foreground mb-6">
              Took a less polluted route to work/school.
            </p>
            <Button 
              onClick={() => handleAction('clean_route')} 
              disabled={!user || actionMutation.isPending}
              className="w-full bg-blue-500/20 hover:bg-blue-500/30 text-blue-400 border border-blue-500/50"
            >
              Log (+30 XP)
            </Button>
          </GlassCard>

          <GlassCard className="border-purple-500/20 hover:border-purple-500/50 transition-colors" delay={0.7}>
            <div className="p-3 rounded-full bg-purple-500/10 w-fit mb-4 text-purple-400">
              <Footprints className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold mb-2">Avoided Exposure</h3>
            <p className="text-sm text-muted-foreground mb-6">
              Stayed indoors during peak pollution hours.
            </p>
            <Button 
              onClick={() => handleAction('avoid_exposure')} 
              disabled={!user || actionMutation.isPending}
              className="w-full bg-purple-500/20 hover:bg-purple-500/30 text-purple-400 border border-purple-500/50"
            >
              Log (+20 XP)
            </Button>
          </GlassCard>
        </div>
      </section>
    </div>
  );
}
