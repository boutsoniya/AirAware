import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import Health from "@/pages/Health";
import Leaderboard from "@/pages/Leaderboard";
import { Layout } from "@/components/Layout";
import { VayuGuru } from "@/components/VayuGuru";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { MapPin, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";

function Router() {
  const [isLocating, setIsLocating] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleUseLocation = () => {
    if (!navigator.geolocation) {
      toast({
        title: "Error",
        description: "Geolocation is not supported by your browser",
        variant: "destructive",
      });
      return;
    }

    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        try {
          const { latitude, longitude } = position.coords;
          const res = await fetch(`/api/aqi?lat=${latitude}&lon=${longitude}`);
          const data = await res.json();
          
          // Update global state via query cache
          queryClient.setQueryData(["/api/aqi/current"], (old: any) => ({
            ...old,
            ...data,
          }));
          
          toast({
            title: "Location Updated",
            description: `Showing data for ${data.location}`,
          });
        } catch (error) {
          toast({
            title: "Error",
            description: "Failed to fetch location AQI",
            variant: "destructive",
          });
        } finally {
          setIsLocating(false);
        }
      },
      () => {
        setIsLocating(false);
        toast({
          title: "Location Denied",
          description: "Location access denied - showing Delhi data",
          variant: "destructive",
        });
      }
    );
  };

  return (
    <Layout>
      <header className="flex items-center justify-between p-4 border-b border-white/10">
        <h1 className="text-xl font-bold text-white">AirAware</h1>
        <Button 
          variant="outline" 
          onClick={handleUseLocation}
          disabled={isLocating}
          className="gap-2"
        >
          {isLocating ? <Loader2 className="w-4 h-4 animate-spin" /> : <MapPin className="w-4 h-4" />}
          Use My Location
        </Button>
      </header>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/health" component={Health} />
        <Route path="/leaderboard" component={Leaderboard} />
        <Route component={NotFound} />
      </Switch>
      <VayuGuru />
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
