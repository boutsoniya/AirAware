## Packages
recharts | For the AQI gauge and air quality charts
framer-motion | For smooth page transitions and micro-interactions
clsx | For conditional class names
tailwind-merge | For merging tailwind classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ['"Exo 2"', 'sans-serif'],
  mono: ['"JetBrains Mono"', 'monospace'],
  display: ['"Orbitron"', 'sans-serif'],
}
