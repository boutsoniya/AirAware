# AirAware

## Overview

AirAware is a health-centric air quality intelligence platform focused on the Delhi-NCR region. It translates real-time pollution data (AQI, PM2.5, PM10) into actionable health advice, provides AI-powered chat assistance through "VayuGuru," estimates lung health impact based on exposure, and gamifies healthy air habits with a points-based leaderboard system.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript, using Vite as the build tool
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state, local state with React hooks
- **Styling**: Tailwind CSS with custom design tokens for AQI status colors (good/moderate/poor/hazardous)
- **UI Components**: shadcn/ui component library with Radix UI primitives
- **Animations**: Framer Motion for page transitions and micro-interactions
- **Charts**: Recharts for AQI gauge visualization

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **API Design**: RESTful endpoints under `/api/*` prefix
- **Build Process**: Custom build script using esbuild for server and Vite for client

### Data Storage
- **Database**: PostgreSQL with Drizzle ORM
- **Schema Location**: `shared/schema.ts` contains all table definitions
- **Tables**: users, aqiReadings, userActions, conversations, messages
- **Migrations**: Managed via `drizzle-kit push` command

### Key Features Implementation
1. **Real-time AQI Display**: Polling every 60 seconds for current air quality data
2. **Location-based AQI**: Geolocation API integration for user's current position
3. **VayuGuru AI Chat**: Anthropic Claude integration for air quality Q&A
4. **Lung Age Calculator**: Health impact estimation based on exposure and sensitivity
5. **Gamification**: Points system for healthy actions (mask wearing, clean routes, exposure avoidance)
6. **Leaderboard**: Ranked display of top contributors with badges

### Project Structure
```
client/           # React frontend
  src/
    components/   # UI components including VayuGuru chat
    hooks/        # Custom React hooks for data fetching
    pages/        # Route pages (Dashboard, Health, Leaderboard)
    lib/          # Utilities and query client config
server/           # Express backend
  routes.ts       # API route definitions
  storage.ts      # Database access layer
  replit_integrations/  # AI chat and batch processing utilities
shared/           # Shared types and schemas
  schema.ts       # Drizzle table definitions
  routes.ts       # API route type definitions
```

## External Dependencies

### AI Services
- **Anthropic Claude**: Used for VayuGuru AI assistant chat functionality
  - Environment variables: `AI_INTEGRATIONS_ANTHROPIC_API_KEY`, `AI_INTEGRATIONS_ANTHROPIC_BASE_URL`
  - Models supported: claude-opus-4-5, claude-sonnet-4-5, claude-haiku-4-5

### Database
- **PostgreSQL**: Primary data store
  - Environment variable: `DATABASE_URL`
  - Connection pooling via `pg` package

### External APIs (Planned/Mock)
- **OpenWeatherMap**: For live location-based AQI data (currently mocked in routes)
- **Geolocation API**: Browser API for user location detection

### Session Management
- **connect-pg-simple**: PostgreSQL-backed session storage

### Key NPM Packages
- `drizzle-orm` / `drizzle-kit`: Database ORM and migrations
- `@tanstack/react-query`: Async state management
- `framer-motion`: Animations
- `recharts`: Data visualization
- `wouter`: Client routing
- `zod`: Schema validation