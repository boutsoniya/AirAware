import { users, aqiReadings, userActions, type User, type InsertUser, type AqiReading, type UserAction } from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql } from "drizzle-orm";

export interface IStorage {
  // User
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPoints(id: number, points: number): Promise<User>;
  
  // AQI
  getLatestAqi(): Promise<AqiReading | undefined>;
  createAqiReading(reading: typeof aqiReadings.$inferInsert): Promise<AqiReading>;
  
  // Actions
  logAction(action: typeof userActions.$inferInsert): Promise<UserAction>;
  
  // Leaderboard
  getLeaderboard(): Promise<User[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUserPoints(id: number, points: number): Promise<User> {
    // Determine badges based on points
    let badge = "";
    if (points >= 100) badge = "Clean Air Champion";
    else if (points >= 50) badge = "Mask Master";
    
    // Append badge if new (simplified logic)
    const [user] = await db.update(users)
      .set({ 
        points: points,
        badges: badge ? sql`array_append(${users.badges}, ${badge})` : undefined
      })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async getLatestAqi(): Promise<AqiReading | undefined> {
    const [reading] = await db.select()
      .from(aqiReadings)
      .orderBy(desc(aqiReadings.timestamp))
      .limit(1);
    return reading;
  }

  async createAqiReading(reading: typeof aqiReadings.$inferInsert): Promise<AqiReading> {
    const [newReading] = await db.insert(aqiReadings).values(reading).returning();
    return newReading;
  }

  async logAction(action: typeof userActions.$inferInsert): Promise<UserAction> {
    const [newAction] = await db.insert(userActions).values(action).returning();
    return newAction;
  }

  async getLeaderboard(): Promise<User[]> {
    return await db.select()
      .from(users)
      .orderBy(desc(users.points))
      .limit(10);
  }
}

export const storage = new DatabaseStorage();
